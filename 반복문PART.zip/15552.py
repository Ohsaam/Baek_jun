n= int(input())

for _ in range(int(n/4)): # 4로 나눈 값 만큼 반복
    print("long ",end="") #이어서 출력
print("int")