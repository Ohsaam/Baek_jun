a = int(input())

for i in range(a):
    c,d = map(int,input().split())
    sum = c+d
    print(c+d)